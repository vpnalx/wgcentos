ALERT:: This is still under testing, use the script at your own risk

